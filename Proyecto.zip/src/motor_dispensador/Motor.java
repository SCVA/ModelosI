package motor_dispensador;

public abstract class Motor {
	public Motor(){
		
	}
	
	public final void operar(){
		encender();
		acelerar();
		detener();
		apagar();
	}
	
	public abstract void encender();
	public abstract void acelerar();
	public abstract void detener();
	public abstract void apagar();
	
	public abstract Motor clonar();
}
