package motor_dispensador;

public abstract class Dispensador {
	public Dispensador(){
		
	}
	
	public abstract Dispensador clonar();
}
