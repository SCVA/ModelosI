package motor_dispensador;

public abstract class FabricaComponente {
	protected Dispensador dispensador;
	protected Motor motor;
	
	public FabricaComponente(){
		
	}
	
	public abstract Dispensador crearDispensador();
	public abstract Motor crearMotor();
}
