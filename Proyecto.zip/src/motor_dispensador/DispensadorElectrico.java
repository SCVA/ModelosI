package motor_dispensador;

public class DispensadorElectrico extends Dispensador{
	public DispensadorElectrico(){
		
	}
	
	@Override
	public Dispensador clonar() {
		return new DispensadorElectrico();
	}
}
