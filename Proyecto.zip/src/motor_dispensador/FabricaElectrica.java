package motor_dispensador;

public class FabricaElectrica extends FabricaComponente{
	public FabricaElectrica(){
		
	}
	
	@Override
	public Dispensador crearDispensador() {
		dispensador = new DispensadorElectrico();
		return dispensador;
	}

	@Override
	public Motor crearMotor() {
		motor = new MotorElectrico();
		return motor;
	}
}
