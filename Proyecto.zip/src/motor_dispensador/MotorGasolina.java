package motor_dispensador;

public class MotorGasolina extends Motor{
	public MotorGasolina(){
		
	}
	
	@Override
	public void encender() {
		
	}

	@Override
	public void acelerar() {
		
	}

	@Override
	public void detener() {
		
	}

	@Override
	public void apagar() {
		
	}

	@Override
	public Motor clonar() {
		return new MotorGasolina();
	}
}
