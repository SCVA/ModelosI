package motor_dispensador;

public class FabricaGasolina extends FabricaComponente{
	public FabricaGasolina(){
		
	}
	
	@Override
	public Dispensador crearDispensador() {
		dispensador = new DispensadorGasolina();
		return dispensador;
	}

	@Override
	public Motor crearMotor() {
		motor = new MotorGasolina();
		return motor;
	}
}
