package motor_dispensador;

public class DispensadorGasolina extends Dispensador{
	public DispensadorGasolina(){
		
	}

	@Override
	public Dispensador clonar() {
		return new DispensadorGasolina();
	}
}
