package agregados;

public abstract class Lista {
	public Lista(){
		
	}
	
	public abstract Iterador crearIterador();
}
