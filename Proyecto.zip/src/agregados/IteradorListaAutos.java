package agregados;

public class IteradorListaAutos extends Iterador{
	
}
