package agregados;

import java.util.ArrayList;

import auto.Auto;

public class ListaAutos extends Lista{
	private ArrayList<Auto> listaAutos = new ArrayList<Auto>();
	
	public ListaAutos(){
		
	}

	@Override
	public Iterador crearIterador() {
		return new IteradorListaAutos();
	}
}
