package agregados;

public class Iterador {

}
