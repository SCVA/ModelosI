package auto;

import motor_dispensador.Dispensador;
import motor_dispensador.Motor;

public class Auto {
	private Motor motor;
	private Dispensador dispensador;
	
	public Auto(){
		
	}

	public Motor getMotor() {
		return motor;
	}

	public void setMotor(Motor motor) {
		this.motor = motor;
	}

	public Dispensador getDispensador() {
		return dispensador;
	}

	public void setDispensador(Dispensador dispensador) {
		this.dispensador = dispensador;
	}
	
	public Auto clonar(){
		Auto duplicado = new Auto();
		duplicado.setDispensador(dispensador.clonar());
		duplicado.setMotor(motor.clonar());
		return duplicado;
	}
}
